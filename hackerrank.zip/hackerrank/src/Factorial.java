import java.util.Scanner;

public class Factorial
{
    public static void main(String[] args) {
 int  a =1;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any no");
        int num= scan.nextInt();
        for(int i = 1; i<=num; i++) {
            a =a*i;

        }
        System.out.println(a);
    }
}
