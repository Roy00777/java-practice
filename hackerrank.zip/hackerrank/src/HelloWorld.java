import java.util.PriorityQueue;
import java.util.Queue;

public class HelloWorld {
    public static void main(String[] args) {

        Queue<String> names = new PriorityQueue<>();


        names.add("Vivek");
        names.add("Vivek");
        System.out.println(names);


        String abc = "Vivek";


        for (int i =0; i< abc.length(); i++){
            int a = abc.length();
            if(a==a){
                System.out.println(abc.length());
            }

        }
    }
}
