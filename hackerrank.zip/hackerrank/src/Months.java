import java.util.Scanner;

public class Months
{
    public static void main(String[] args) {
        int months;
        System.out.println("enter any months");
        Scanner scan = new Scanner(System.in);
        months=scan.nextInt();
        if(months <= 3 && months <= 5){
            System.out.println("its  spring");

        } else if (months <= 6 && months <= 8)
        {
            System.out.println("its Summer");
        }
    else if (months <= 9 && months <= 11){
            System.out.println("its Rain");

        }
        else if (months == 12 || months == 1 || months==2){
            System.out.println("its Winter");
        }
        else {
            System.out.println("invalid season");
        }
    }
}
