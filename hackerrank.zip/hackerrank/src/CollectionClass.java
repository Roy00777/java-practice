import java.sql.SQLOutput;
import java.util.*;


public class CollectionClass {
    public static void main(String[] args) {
        //we have many functions in it

        List<Integer> list = new ArrayList<>();
        list.add(35);
        list.add(22);
        list.add(65);
        list.add(12);
        list.add(5);

        //Minimum and Maxium function which are provided by
        //collection

        System.out.println("min element" +" "+ Collections.min(list));

        // max element
        System.out.println("max element" + " "+Collections.max(list));
    //Frequecy which will tell you the repeated Element
        System.out.println(Collections.frequency(list,9 ));

        // Sorting in Collection
        //using Comparator we  can reverse the order
        Collections.sort(list, Comparator.reverseOrder());
        System.out.println(list);

        //working on Comparable
        List<Student>  lista =new ArrayList<>();
        lista.add(new Student("Anuj", 2));
        lista.add(new Student("Ramesh", 2));
        lista.add(new Student("Shivam", 2));
        lista.add(new Student("Rohit", 2));

        //Now we can dyanamicly compair by name or rollno
        Collections.sort(lista, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.name.compareTo(o2.name);
            }

            });
        System.out.println(lista);
        }
    }
//************* Comparable **************
// In comaparable we can compare one variable at a time
// there is only one comaprable method in one class


//*************Comparator ***************

// we can have multiple comparator method in single class