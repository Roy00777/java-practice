import java.util.Scanner;

public class Do_while
{
    public static void main(String[] args) {
int num,a=0,b=0,c=0;
        Scanner scan = new Scanner(System.in);
        do{
            System.out.println("enter any no");

            num=scan.nextInt();
if(num<0){
    a++;
}
else   {
    c++;

}

        }while(num !=-1);
        System.out.println("out of loop");
        System.out.println("Total Positive Number: "+c);
        System.out.println("Total Negative Number"+a);
    }
}
