import java.lang.reflect.Array;
import java.util.Arrays;

public class LearnArraysClass {
    //these are bassiclly use to manupulate the array

    public static void main(String[] args) {
        int numbers[] = {1,2,3,4,5,6,7,8,9,10};
        //we can use binarySearch directly
        int index = Arrays.binarySearch(numbers, 4);
        System.out.println("the index of element of 4 :" + index);

        // we can sort the array using Array.sort
        //function
        int sort[] ={2,4,6,8,7,9,1,5,3,4};
        Arrays.sort(sort);

        //itreation on Array
        for (int i : numbers){
            System.out.println(i +" ");
        }
        Arrays.fill(numbers, 121);
        for (int i:numbers) {
            System.out.print(i+ " ");

        }
    }
}
