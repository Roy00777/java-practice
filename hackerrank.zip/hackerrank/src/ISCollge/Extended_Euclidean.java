package ISCollge;

import java.lang.*;
import java.util.*;




public class Extended_Euclidean {




        // extended Euclidean Algorithm
        public static int[] gcdExtended(int gghj, int gghj2) {
            int r = -1;
            int q = -1;
            int t1 = 0, t2 = 1;
            int s1 = 1, s2 = 0;
            int t = -1, s = -1;

            int result[] = new int[3];

            do {
                q = gghj / gghj2;
                r = gghj % gghj2;

                t = t1 - (q * t2);
                s = s1 - (q * s2);

                gghj = gghj2;
                gghj2 = r;

                t1 = t2;
                t2 = t;

                s1 = s2;
                s2 = s;

            } while(r != 0);

            result[0] = gghj;
            result[1] = t1;
            result[2] = s1;

            return result;
        }

        // Driver Program
        public static void main(String[] args)
        {
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter the value of a and b to find the gcd: ");
            int gghj = scan.nextInt();
            int gghj2= scan.nextInt();
            int g[];

            g = gcdExtended(gghj, gghj2);

            System.out.println("gcd(" + gghj + ", " + gghj2 + ") = " + g[0]);
            System.out.println("t: " + g[1] + " and s: " + g[2]);
            System.out.println("s x a + t x b : " + Math.abs( (g[2] * gghj) + ( g[1] * gghj2) ));

//            if (Math.abs( (g[2] * gghj) + ( g[1] * gghj2 ) ) == g[0]) {
//                System.out.println("True");
//            }
//            else {
//                System.out.println("False");
//            }
//
//            scan.close();
        }
    }



