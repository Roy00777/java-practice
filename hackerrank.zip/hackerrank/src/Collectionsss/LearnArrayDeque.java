package Collectionsss;

//use ArrayDeque we can remove element from front and rear
// and we can peek it from front and rear

import java.util.ArrayDeque;
import java.util.Queue;

public class LearnArrayDeque {
    public static void main(String[] args) {
        //Creation of ArrayDeque
        // there are some unique function of Array deque

        ArrayDeque<Integer> ad = new ArrayDeque<>();
        // when we use "offer" to add element in queue is
        // it will add the element in the end of the queue
        ad.offer(32);
        // but if we use "offerFirst" it will add the element from the front of queue
        ad.offerFirst(12);
        //same way "offerLast" is use to add element in last
        ad.offerLast(10);
        ad.offer(2);
        System.out.println(ad);
        //same for peek too see the first and last we can use it  like
        //first normal peek
        System.out.println(ad.peek());
        System.out.println(ad.peekFirst());

        System.out.println(ad.peekLast());
        //same goes for poll to remove first and last we will use
        ad.poll();
        System.out.println(ad);
        ad.pollFirst(); // in our case it will 12
        System.out.println(ad);
        ad.pollLast(); // it will be 2
        System.out.println(ad);
    }
}
