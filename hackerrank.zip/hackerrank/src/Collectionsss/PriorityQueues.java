package Collectionsss;


import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueues {
    public static void main(String[] args) {
        //Creation of prioprity
        // By default the priority is default small> to higher
        //smaller the element higher its priority
        // we can also create priority like these to
        //*********************
//        PriorityQueue<Integer> pq = new PriorityQueue<>();
        //*********************
        //we can declar the Priority Queue like this also
        Queue<Integer> pq = new PriorityQueue<>(Comparator.reverseOrder()); // comparator we can make the higher element has
        //the higher value
        pq.offer(45);
        pq.offer(65);
        pq.offer(55);
        pq.offer(35);
        System.out.println(pq);

 // if i will poll the element then the 35 will be the output
 // because its a smaller element
 // poll work as the same as stack it will remove
 // the samller element from it

  pq.poll();
        System.out.println(pq);

        pq.peek(); // these on will show us the which one will be the next to remvoe in prority
        System.out.println(pq.peek());

        // if you want to set the priority then we can use
    }
}
