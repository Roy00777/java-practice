package Collectionsss;

import java.util.Set;
import java.util.TreeSet;

public class TreesetLearn {
    public static void main(String[] args) {
        // all the element will be in the sorted form
        // because it having the properties of Binary tree and set
        Set<Integer> set = new TreeSet<>();
        set.add(22);
        set.add(21);
        set.add(20);
        set.add(23);
        set.add(23);
        System.out.println(set);
// and the rest code is the same as the set

    }

}
