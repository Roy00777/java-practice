package Collectionsss;

//Queue is the interface which is use Array list or linklist


import java.util.LinkedList;
import java.util.Queue;

public class LearnLinkListQueue {
//creation of the Queue
    //Queue<Datatype> queue = new (list nay u want to apply)
    // in our case its Linklist
public static void main(String[] args) {
    Queue<Integer> queue = new LinkedList<>();
//to add the element we use Offer keyword
    queue.offer(55);
    queue.offer(45);
    queue.offer(35);
    queue.offer(65);

    System.out.println(queue);
// this is 1st in 1st out because its a queue
    //remove function will work as the 1st which is insert
    //will get remove 1st
    // we use poll for it
    queue.poll(); // it will remove 55
    System.out.println(queue);
// Peek function use in queue is use the show the first element

    System.out.println(queue.peek()); // its show us 45
// if queue is empty then it will show null but if we use element functionn it will show us an execpetionn\
    // same if we use the add function in queue but because of some secniro it
    // not get add then it throw an error
    // in Case offer it will gave us true or fase

}




}
