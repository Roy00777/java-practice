package Collectionsss;
//Array list is like a normal arrays
// but in array we cant resize the array dynamiclly
//We get the feature in the Array list which
// is dynamiclly extent the size
// Array list use internally is Array


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListCollections {
    // Creating a Arraylist
    public static void main(String[] args) {
        //Arraylist then the type of variable in our case its String
        // then variable name
        // And lastly = to new Arraylist<>();


        // this a one type we can declre the arraylist
         ArrayList<String> studentName = new ArrayList<>(); // this create a empty list // Arraylist is a class which have impimented list
        //after adding any value in it then the
        // Arraylist provide size of 10 initialy
        studentName.add("Ramesh");
        //so you can insert 0 to 9 value then who its extend dynamily
        // so suppose there is n size array  then we need to add some more value
        // the formula should be like  n+n/2+1
        // means if we have 10 value so wee need to add some more value the array size increase
        // 10+10/2+1 = 16
        // more 6 size array will add


    // 2 type which is genrelly use
        // List then type of <varibale>  then list name
        // finally  the equal to new Arraylist
        // with these prosess we can create any type of list
        // like linklist and etc just chage ArrayList to Linklist
        List<String> list = new ArrayList<>();
        list.add("0");
        list.add("1");
        list.add("2");
        list.add("3");
        System.out.println(list);
        //the 5 will be add in the array at last
        list.add("4");
        System.out.println(list);

        // adding value into particular index
        list.add(1,"6");// in this we will pass the index first after that we will the value
        System.out.println(list);

    // We can add a list into a list
        List<String> newList = new ArrayList<>(); // created  a new list
        //add the value in the list
        newList.add("150");
        newList.add("20000");

        // megering 2 list  using addAll function
        list.addAll(newList); // this will add the element of newlist to list
        System.out.println(list);

        // want some particular value from the list
        // list.get(index no) will gave you the value of the particular index which you have passes in it
        System.out.println(list.get(4));

        //REmove the element form the ArrayList
        //same as get just write remove
        //list.remove(index number)

        System.out.println(list.remove(4));
        System.out.println(list);

        //Removeing the value Particular value(element)
        // we will pass the datatype ofthe variable
        // and .valueof (pass the desire output)
        // in overcase datatype is Integer
        //so Integer.valueOf(2000)
        // 2000 we want to remove

        list.remove("20000");
        System.out.println(list);

//        //Updating the value of in Arraylist
//        // we pass the index in which we have to update the value
//        // and comma the value we want on that index
//        list.set(2,33); // set fuction will set the value means it update it
//        System.out.println(list);
//
//        //If you want to see is there any value is present or not
//        // its a boolean  function  which give us true if present and false if its not
//        // we will pass the element/ value not the index
//
//        System.out.println(list.contains(54));
//
// // *****      //If you what  to itrate on the Arraylist /***
//        for (int i=0; i<list.size(); i++){
//            System.out.println("the element is :"+ list.get(i));
//        }
//        // we can use ForEach loop
//        for (Integer element:list) {
//            System.out.println("for each the element is :"+ element);
//
//        }
//
//        // we have the itrater function in the list
//        //Iterator <datatype> and its name
//        //list.iterator for iteration
//        Iterator<Integer> it = list.iterator();
//        //hasNext will check is there any value after a value
//        // which menas akhir tak dekhte rahenga or koi hai value
//        while (it.hasNext()){
//            System.out.println("iterator"+it.next()); // we can print it using next
//        }
//
//        //Remove the whole list / Cleaning up the list
//
//        list.clear(); // this will remove all the element from the list
//        System.out.println(list);




    }
//o[N] time complexibility
}
