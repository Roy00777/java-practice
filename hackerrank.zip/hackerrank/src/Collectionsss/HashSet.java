package Collectionsss;
// we cant have duplicate in hash set


import java.util.Set;

public class HashSet {
    public static void main(String[] args) {
        //Creation of the Hashset
        //Order of the element are not maintain

        Set<Integer> set = new java.util.HashSet<>();
        set.add(22);
        set.add(21);
        set.add(20);
        set.add(23);
        set.add(23);// i am trying to add same element but it will have one
        // which have been set first

        System.out.println(set);
        //************* Remove
// set will directly remove the element
        set.remove(20);
        System.out.println(set);

        //**** Contain
        // contain we have seen it in the list
        // its a bollan type if the element present it will gave true if not then false

        System.out.println(set.contains(55));

        //isEmpty is a fucntion which tells us is the set is empty or not
        System.out.println(set.isEmpty()) ;

        //size will tell you the size of the set
        System.out.println(set.size());


    }

    // then there is linKHashSet
    // it will have the properties of the set and linklist
    // in which our order of the element will be maintain

}
