package Collectionsss;
//last in first out
// we haveto create a object of stack class


import java.util.Stack;

public class StackCollection {
    public static void main(String[] args) {

        //creation of stack object
        //Stack<datatype> nameofstack and equal to new stack
        Stack<String> animals =new Stack<>();
        //to add the element in the stack we use push

        animals.push("Lion");
        animals.push("Dog");
        animals.push("cat");
        animals.push("Tiger");

        System.out.println(animals);

        //******Peek******
        //Peek is use to see the top most element in the stack

        System.out.println(animals.peek());

        //To remove any element we use pop
    //pop will remove the topmost element because its a stack
        // we know it s last in first out
        // in our case its a  Tiger  will remove
        // then the latest one on top will cat


        animals.pop();
        //after remove
        System.out.println(animals);


//the new one in the top after tiger remove its cat
        System.out.println(animals.peek());




    }

}
