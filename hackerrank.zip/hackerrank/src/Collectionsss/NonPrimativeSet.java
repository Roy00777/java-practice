package Collectionsss;

import java.util.HashSet;
import java.util.Set;

public class NonPrimativeSet {
    public static void main(String[] args) {
        Set<Student> set = new HashSet<>();
        set.add(new Student("Rahul", 25));
        set.add(new Student("Sanju", 24));
        set.add(new Student("Shivam", 26));
        set.add(new Student("Rohit", 25));
        set.add(new Student("Lahul", 27));
        // so we already know that  Hashset dont store the same element
       // if we print set directly it will give us a random hexadeciml character
        // because we havent created a toString method
        // before that go in student class and create ToString method
        System.out.println(set);
        // Now it will not take the same roll no
        // because of the equal and hashset method where applied
        // on Student Class
    }
}
