package Mappss;
// Maps Store the key and value pair
// you can have different type of keys
// like integer, String etc of datatype
// Aslo goes for Value
// u can have integer, string etc of datatype

import java.util.HashMap;
import java.util.Map;
// Always remember key should be unique
// it will not take same key

public class HashMapLearn {
    public static void main(String[] args) {
        //Creation of Maps
        //Map<key datatype, value datatype> name and then new what ever mapp u want
        // in our case we are looking at hashMap
        Map<String , Integer> number = new HashMap<>();
        // to add element in Map we use put
        number.put("One", 1);
        number.put("Two", 2);
        number.put("three",3);
        System.out.println(number);
        number.put("Two", 4); // it will override the key value form 2 to 4
        //becaue its having the common key in it
        System.out.println(number);
        //Now if you need to check if the key is present
        //then you should use "if conditions"

        //below code expalin
        // if there Two is abesent
        //then you can add "Two", 23
        //if its present donot insert it

//        if (!number.containsKey("Two")){
//            number.put("Two", 23);
//        }
//        System.out.println(number);

        //the below code work same as the if condition
        // its have putIfAbsent
        number.putIfAbsent("Two", 23);
        // if we dont use putIfAbsent then if there is same key
        // it will override the value

        //For Itration on HashMap

        for (Map.Entry<String, Integer> e : number.entrySet()){
            System.out.println(e.getKey());
            System.out.println(e.getValue());
        }
        //it will only return the keys present
//       for (String key : number.keySet()){
//           System.out.println(key);
//       }
//       //same wwe can get the value also
//        for (Integer value : number.values()){
//            System.out.println(value);
//        }

        //it will shows as the value is present or not
        //contain.value(Value which you want we see is present or not)
        System.out.println(number.containsValue(3));

        //below function isEmpty will show us that hash is empty or not
        System.out.println(number.isEmpty());


        //remove
        number.remove(3);

    }
}
