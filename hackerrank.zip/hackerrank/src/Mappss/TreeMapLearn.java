package Mappss;

import java.util.Map;
import java.util.TreeMap;


// it will store the element in sorted form
// because internal use is binary search tree

public class TreeMapLearn {
    public static void main(String[] args) {
        Map<String, Integer> number = new TreeMap<>();
        //Entries are not in sorted form
        // It will sorted it on the key
        // in our condition key is string means A to Z
        // A is on the top an Z in on the botton
        //alfabettcly
        number.put("One", 25);
        number.put("Two", 2);
        number.put("Three",8);
        number.put("Four",9);
        number.put("Five",0);
        System.out.println(number);
    }
}
