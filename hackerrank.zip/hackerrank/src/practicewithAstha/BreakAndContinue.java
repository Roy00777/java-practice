package practicewithAstha;

public class BreakAndContinue {
    public static void main(String[] args) {
        System.out.println("practice of break and continue");
        int a = 20;
        for (int i = 0; i <= a; i++){
            if (i==5) {
                System.out.println(i);
            }
//            System.out.println(i);
//            break;
            continue;



        }
    }
}
