package practicewithAstha;

import java.util.Scanner;

public class pWaArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        int size=scanner.nextInt();
//        part one of declaration of an array


//        int arr[]={1,2,3,4,5};
//        for (int i=0; i<arr.length; i++){
//            System.out.println(arr[i]);
//

//        }
//        part 2 of an array
//        int[] arr = new int[size];
//        //for input we have create loop input will be taken from the user
//        for (int i=0; i<size; i++){
//            arr[i]=scanner.nextInt();
//
//        }
//        //for output
//        for (int i=0; i<size; i++){
//            System.out.println(arr[i]);
//        }
// Tring some of the problem
        System.out.println("Enter the value of x:");
        int x = scanner.nextInt();
        int[] arr ={1,2,3,5,4,7,8,9,6,45,55,77,22,35,65,14,85,75,49,98,99,45477,65,78,4558};
        for (int i =0; i<arr.length; i++) {
            if (x == arr[i]) {
                System.out.println("your desire value is \n" +arr[i]);
            }


        }
    }
}
