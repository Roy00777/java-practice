package Binaryi_Brain;

import java.util.Scanner;

public class Array_Demo {
    public static void main(String[] args) {
        int a[] = new int[4];
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any array : ");
        for (int i = 0; i < 4; i++) {
            a[i] = scan.nextInt();
        }
        System.out.println("This is ur array");
        for (int i = 0; i <4; i++) {
            System.out.println(a[i]);
        }


    }
}

