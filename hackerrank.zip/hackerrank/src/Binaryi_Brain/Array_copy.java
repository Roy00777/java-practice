package Binaryi_Brain;

import java.util.Scanner;

public class Array_copy {



    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
//        System.out.println("enter size");
//        int size = scan.nextInt();

        int a[] =new int[]{10,20,3,45};


//        int arr[] = new int[a.length];
      int arr[]= new int[a.length];
        for (int i = 0; i < a.length; i++) {

             arr[i] = a[i];


        }

        System.out.println("This are original size");
        for (int i = 0; i <a.length ; i++) {
            System.out.println(a[i]);

        }
        System.out.println("This are copy array");
        for (int i = 0; i <arr.length ; i++) {
            System.out.println(arr[i]);

        }
    }
}
