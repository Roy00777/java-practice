package Binaryi_Brain;



import java.sql.SQLOutput;
import java.util.Scanner;

public class Electric_Bill {
    public static void main(String[] args) {
        int unit, bill;
        Scanner scan= new Scanner(System.in);
        System.out.println("enter ur unit");
        unit= scan.nextInt();


        if(unit<=100){
            System.out.println("u r bill is :");
            bill=unit*3;
            System.out.println(bill);

        } else if (unit>=101 && unit<=300) {
            System.out.println("u  r bill is: ");
            bill=((unit-100)*5)+100*3;
            System.out.println(bill);

        } else if (unit>=301) {
            System.out.println("u  r bill is:");
            bill=(((unit-100)-200)*7)+100*3+200*5;
            //bill=unit*7;
            System.out.println(bill);
        }
    }



}
