package Binaryi_Brain;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class largestNOin_while
{
    public static void main(String[] args) {
        int num, large=0, rem;
        Scanner scan=new Scanner(System.in);
        System.out.println("enter any no");
        num= scan.nextInt();

        while(num>0){
            rem=num%10;
            large=rem;
            num=num/10;
        }

        System.out.println(large);
    }

}
