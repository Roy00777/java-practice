package Binaryi_Brain;
import java.util.Arrays;
import java.util.Scanner;
public class Array_Demo3
{

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("How many elements ? ");
        int size = scan.nextInt();

        int a[] = new int[size];

        System.out.println("Enter array ");
        for(int i = 0;i<size;i++)
        {
            a[i] = scan.nextInt(); //34 67 12 5 9
        }



        Arrays.sort(a) ; //5 9 12 34 67
        System.out.println("Largest is " + a[size - 1]
        );


    }
}

