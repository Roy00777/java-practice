package Binaryi_Brain;

import java.util.Scanner;

public class Reverse_Number {
    public static void main(String[] args) {
        int  num,a, b, c, d, rev;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any four digit number");
        num=scan.nextInt();
        a=num%10;
        b=(num/10)%10;
        c=(num/100)%10;
        d=(num/1000)%10;
        rev= a*1000+b*100+c*10+d*1;
        System.out.println("ur reverse number is :"+rev);

    }



}
