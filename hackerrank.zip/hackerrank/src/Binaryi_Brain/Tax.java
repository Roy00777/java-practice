package Binaryi_Brain;

import java.util.Scanner;

public class Tax {

    public static void main(String[] args) {

        float sal ,   tax;
        Scanner scan= new Scanner(System.in);
        System.out.println("Enter ur salary");
        sal= scan.nextFloat();

        if(sal<15000){
            System.out.println("u don't need to pay tax");
        } else if (sal>=150001 && sal<=300000) {
            System.out.println("u have pay 10% of ur salary");
            tax= sal/10;
            System.out.println("that is :"+tax);
        } else if (sal>=300001 && sal <= 500000 ) {
            System.out.println("u have to pay 20% of ur salary");
            tax=sal/20;
            System.out.println("that is :" +tax);

        }
        else {
            System.out.println("u have to pay 30% of ur  salary");
            tax= sal/30;
            System.out.println("that is :"+tax);
        }
    }




}
