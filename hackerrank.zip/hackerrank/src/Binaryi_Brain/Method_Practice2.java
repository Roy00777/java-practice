package Binaryi_Brain;

import java.util.Scanner;

public class Method_Practice2 {

    public int Greatest( int a,int b,int c){

        int r;
        if(a>b && a>c){

//            System.out.println("The Greatest among three :"+a);
            r=a;
return r;

        } else if (b>a && b>c) {

//            System.out.println("The Greatest among three :"+b);
            r=b;
            return r;
        }
        else{

//            System.out.println("The Greatest among three :"+c);
            r=c;
            return r;
        }


    }

    public static void main(String[] args) {
int a,b,c ;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the value of  a ");
        a= scan.nextInt();
        System.out.println("Enter the value of b ");
        b=scan.nextInt();
        System.out.println("Enter the value of c ");
        c=scan.nextInt();
        Method_Practice2 practice=new Method_Practice2();
        int r=practice.Greatest(a,b, c);
        System.out.println("the Greatest among the three value is :"+r);


    }
}
