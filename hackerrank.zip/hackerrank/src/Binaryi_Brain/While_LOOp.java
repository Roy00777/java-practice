package Binaryi_Brain;

import java.util.Scanner;

public class While_LOOp
{
    public static void main(String[] args) {
        int num,rem,sum=0;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any no.");
        num= scan.nextInt();
        while (num>0){
            rem=num%10;// yaha pahile  input no ka module niklenga or rem me save honga
            sum=sum+rem;//fir yaha jo rem me jake save hoga
                    num= num/10;// fir yaha divide hoga to reminder nhi milenga or fir se loop me num ki value assine hogi

        }

        System.out.println(sum);
    }
}
