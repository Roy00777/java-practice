package Binaryi_Brain;

//import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class Restaurants {
    public static void main(String[] args) {
        int Bill, a = 0, b = 0, c = 0, d = 0, plates=0;
        char chr = 0;
        Scanner scan = new Scanner(System.in);
        System.out.println(" Which Order u like: ");

        int order = 0;
        do {
            System.out.println("1.idli\n2.Dosa\n3.Wada\n4.kachori\n5.Exit");
            order = scan.nextInt();

            if (order !=5 && order<6) {
                System.out.println("plates");
                plates= scan.nextInt();
            }

                if (order == 1) {
                System.out.println("Idli");
                a = plates* 50;

                } else if (order == 2) {
                System.out.println("Dosa");
                b = plates * 100;

            } else if (order == 3) {
                System.out.println("Wada");
                c = plates * 50;
            } else if (order == 4) {
                System.out.println("kachori");
                d = plates * 25;


            } else if (order==5) {
                    System.out.println("Do u really wanna exit, y/n");
                    chr = scan.next().charAt(0);
                    Bill=a+b+c+d;
                    System.out.println("Your Total bill is: "+Bill);

                }else {
                    System.out.println("invalid input");
                }


//            Bill=a+b+c+d;
//            System.out.println("Your Total bill is: "+Bill);

        }while (chr !='y') ;



    }
}
