package Binaryi_Brain;

import java.util.Scanner;

public class Methods {
    public void add(){
        int n1,n2,n3;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter any 2 number");
        n1=scan.nextInt();
        n2=scan.nextInt();
        n3=n1+n2;
        System.out.println("The addition is :"+n3);

    }

    public static void main(String[] args) {
        Methods met=new Methods();
            met.add();

    }
}
