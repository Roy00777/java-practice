package Binaryi_Brain;

public class Array_Demo2 {
    public static void main(String[] args) {
        int a[]={10,20,30,40,50};
        for (int i = 0; i< a.length; i++){
            System.out.println(a[i]);
        }
        for (int x : a) {
            System.out.println(x);

        }

    }
}
