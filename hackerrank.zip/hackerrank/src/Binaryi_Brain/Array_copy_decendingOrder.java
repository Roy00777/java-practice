package Binaryi_Brain;

import java.util.Scanner;

public class Array_copy_decendingOrder {
    public static void main(String[] args) {
        Scanner scan =new Scanner(System.in);
        System.out.println("enter array size");
        int size = scan.nextInt();
        int[] a =new int[size];
        int arr[]=new int[a.length];
        for (int i = 0; i <a.length;i++) {
           a[size]=scan.nextInt();

        }
        for (int i = 0; i < size-1 ; i++) {
            arr[i]=a[i];

        }
        System.out.println(arr);
    }

}
