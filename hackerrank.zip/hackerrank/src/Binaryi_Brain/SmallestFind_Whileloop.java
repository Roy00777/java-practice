package Binaryi_Brain;

import java.util.Scanner;

public class SmallestFind_Whileloop {
    public static void main(String[] args) {
        int num,rem,small=0;
        Scanner scan=new Scanner(System.in);
        System.out.println("enter any no" );
        num= scan.nextInt();
        while(num>0){
            rem = num % 10;
            if(small>rem) {

                small = rem;


            }
            num= num/10;

        }
        System.out.println(small);

    }
}
