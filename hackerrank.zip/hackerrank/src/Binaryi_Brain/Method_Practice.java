package Binaryi_Brain;

import java.util.Scanner;

public class Method_Practice {
    public static    String full_Name (String first_name, String middle_name, String last_name) {
        String v = (first_name+" " + middle_name+" " + last_name);
        return v;

    }

    public static void main(String[] args) {
        String first_name, middle_name, last_name, full_name;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter u r First Name");
        first_name = scan.next();
        System.out.println("Enter u r Middle Name");
        middle_name = scan.next();
        System.out.println("Enter u r Last Name");
        last_name = scan.next();
        Method_Practice method = new Method_Practice();
        String v = method.full_Name(first_name, middle_name, last_name);
        System.out.println("u r fullname is : \n" + v);


    }



}