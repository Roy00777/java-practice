package Binaryi_Brain;

import java.util.Scanner;

public class Array_Boolean {
    public static boolean search (int a[],int num)
    {
        boolean found =false;
        for (int i = 0; i < a.length ; i++) {
            if(a[i]==num){
                found=true;
                break;
            }

        }
         return found;

    }

    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        System.out.println("Enter array size");
        int size= scan.nextInt();
        System.out.println("Enter array");
        int a[]=new int[size];
        for (int i = 0; i <a.length; i++) {
            a[i]=scan.nextInt();


        }
        int num;
        System.out.println("Enter the finding value");
        num= scan.nextInt();

        Array_Boolean array = new Array_Boolean();
        boolean found =array.search(a, num);
//        bollean found=Array_Boolean.search(a,num);
        System.out.println("The value is : "+found);
    }
}
