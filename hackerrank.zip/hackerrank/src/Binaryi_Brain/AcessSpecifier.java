package Binaryi_Brain;

public class AcessSpecifier {
}

//access specifer class ke baher valo ke liue hote hai(bhaer wale class ke liye)

// type of acce
// public
//private
//protected
//package
