package Binaryi_Brain;

import java.util.Scanner;

public class Method_Practice_3 {
    public float tax(float sal) {
        float tax=0;
        if (sal >= 1 && sal <= 150000) {
            System.out.println("u don't need to pay tax");


        } else if (sal >= 150001 && sal <= 300000) {
            System.out.println("You have to pay 10% of u r salary");
            tax = sal / 10;


        } else if (sal >= 300001 && sal <= 500000) {
            System.out.println("You have to pay 20% of ur salary");
            tax = sal / 20;


        } else if (sal >= 500001) {
            System.out.println("You have to pay 30% of ur salary");
            tax = sal / 30;

        }
        return tax;
    }

    public static void main(String[] args) {
        float sal;
        Scanner scan =new Scanner(System.in);
        System.out.println("Enter ur salary :");
        sal=scan.nextFloat();
        Method_Practice_3 hhh=new Method_Practice_3();
        float tax=hhh.tax(sal);
        System.out.println("These % of tax u have to pay:"+tax);
    }
}
