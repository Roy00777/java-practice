package Binaryi_Brain;

import java.util.Scanner;

public class Array_Demo_For_each {
    public static void main(String[] args) {
        System.out.println("Enter array");
        Scanner scan = new Scanner(System.in);
        int size= scan.nextInt();
        int a[]=new int[size];
        int poss=-1, num;
        num= scan.nextInt();

        for (int i = 0; i <size ; i++) {
            a[i]=scan.nextInt();

            if (num == a[i]){
                poss=i;
                break;
            }
            if(poss==-1){
                System.out.println("invalid input");
                break;
            }
            else{
                System.out.println("found at "+poss);
            }
        }
    }
}
