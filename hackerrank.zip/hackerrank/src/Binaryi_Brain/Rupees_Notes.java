package Binaryi_Brain;

import java.util.Scanner;

public class Rupees_Notes {
    public static void main(String[] args) {
        int rupees,a, b,c,d,e,f,g;
        Scanner scan= new Scanner(System.in);
        System.out.println("Enter u r withdraw rupees");
        rupees= scan.nextInt();
        a=(rupees/2000);
        //System.out.println("the 2000rs notes required is:"+a);
       b=(a/10)/20;
       c=(b/2000)%100;

       g=(rupees/2000);
       //

    }


}
