package Binaryi_Brain;

import java.util.Scanner;

public class Placement
{
    public static void main(String[] args) {
        int cse, mech, mca;
        Scanner scan = new Scanner(System.in);
        System.out.println("enter cse placement");
        cse= scan.nextInt();
        System.out.println("enter mech placement");
        mech=scan.nextInt();
        System.out.println("enter mca placement");
        mca= scan.nextInt();
        if(cse == 0 || mech == 0 || mca ==0){
            System.out.println("invalid session");

        } else if (cse >= mech && cse >= mca)
        {

            System.out.println("cse got highest placement");

        } else if (mech >= cse && mech >= mca) {
            System.out.println("mech got highest placement");

        } else if (mca >= cse && mca >= mech) {
            System.out.println("mca got highest placement");

        } else if (cse == mech && mca< cse){
            System.out.println("cse and mech got highest placement");

        } else if (mech==mca && mca> cse) {
            System.out.println("mech and mca got highest placement");
        } else if (mca == cse  && mech <cse) {
            System.out.println("mca and cse got highest placement");

        }
        else{
            System.out.println("non of the deparment got the highest placement");

        }
    }
}
