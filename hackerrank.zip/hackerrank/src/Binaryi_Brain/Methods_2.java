package Binaryi_Brain;

import com.sun.tools.javac.Main;

import java.util.Scanner;

public class Methods_2 {
    //Area of  a Rectange
    public float area(float l, float b) {
        float a = l * b;
        return a;
    }

    public static void main(String[] args) {
        float l,b;
        Scanner scan= new Scanner(System.in);
        System.out.println("enter the length");
        l= scan.nextFloat();
        System.out.println("enter the breath");
        b= scan.nextFloat();
        Methods_2 meth=new Methods_2();
        float a=meth.area(l,b);
        System.out.println("Area of a rectange"+a);

    }
    }

