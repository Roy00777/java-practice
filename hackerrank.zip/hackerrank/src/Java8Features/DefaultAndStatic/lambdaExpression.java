package Java8Features.DefaultAndStatic;

public class lambdaExpression {

    //creating a normal method

    private void sayHello(){
        System.out.println("Hello");



        // Creating Lambda expression
      //here we are takeing two varible to add

 //        (int a, int b) ->{
//            System.out.println(a+b);
//        }

    }
}


//Step to make any function lambda expression
//1 ) Remove Modifier
//2 ) Remove return type
//3 ) Remove method name
//4 ) place arrow

//5 ) if there is