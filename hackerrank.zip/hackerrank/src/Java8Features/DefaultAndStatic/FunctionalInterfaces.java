package Java8Features.DefaultAndStatic;


// in functional interface we only have one abstract method

//can have n number of default or static method
//@functional Interface annotation show is it functionl interface or not

@FunctionalInterface
public interface FunctionalInterfaces {
    public void sayHello();

    default void sayBye(){
        System.out.println("SayBye");
    };
    static void sayReturn(){
        System.out.println("we will return");
    };

}


