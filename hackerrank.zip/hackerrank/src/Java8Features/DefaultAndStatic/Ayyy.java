package Java8Features.DefaultAndStatic;

public class Ayyy implements FunctionalInterfaces {
    public static void main(String[] args) {
        FunctionalInterfaces.sayReturn();
        Ayyy a = new Ayyy();
        a.sayBye();
        a.sayHello();

    }


    @Override
    public void sayHello() {
        System.out.println("aaaa dekhe jara");
    }

    @Override
    public void sayBye() {
        FunctionalInterfaces.super.sayBye();
    }
}
