package Java8Features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Streameee2 {
    public static void main(String[] args) {

        List<String> list= Arrays.asList("apple", "banana", "cherry");
        //creating a steam
        Stream<String> myStream = list.stream();


        //Converting Arrays into stream

        String[] arrayss ={"apple", "banana", "cherry"};
        Stream<String> stream = Arrays.stream(arrayss);


        //when you dont care of the collection  then directly use it

        Stream <Integer> directStream =  Stream.of(1,2, 3);


        //Creating direct Stream
        //Stream.itrate is use to create the next element of the stream
        // stream .iterate accpet unary operator

        Stream<Integer> limit = Stream.iterate(0, n -> n + 1).limit(100);

        // creating Stream using Supplier

        Stream<Integer> limit1 = Stream.generate(() -> (int) Math.random() * 100).limit(5);



        //Working On Collection using stream


        List<Integer> list3 = Arrays.asList(1,2,3,4,5,6,7,8,9,4,654,2,2,2,1321,132,33,3,3,13465,13,40);
       List<Integer> filterList = list3.stream().filter(x -> x % 2 == 0).collect(Collectors.toList());
        System.out.println(filterList);

        List<Integer> mapplist= filterList.stream().map(x -> x / 2).collect(Collectors.toList());
        System.out.println(mapplist);
    }
}
