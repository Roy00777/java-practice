package Java8Features;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

//Functions:-  Function is functinal interface where we have single abstact apply method
// in apply we can pass any kind of paramenter and return
public class FunctionsPrac {
    // here in function we can take any kind of datatype input
    //and we can return different type of output or same type of it
    // for example we pass integer as input and we want return in string we can get it


    public static void main(String[] args) {
//        Function<String, Integer> getLength = x -> x.length();
//        System.out.println(getLength.apply("helloWorld"));  // here we pass String and we have output means return in Integer
//        // writing another function to get first 3 letter of the string
//
//        Function<String, String> function2 = s -> s.substring(0, 3);
//        //  System.out.println(function2.apply("your my only bunny"));
////creating another function where we will the list
//
//        //pass the Student
//        Function<List<Student>, List<Student>> studentsWithVipAsPrefix = li -> {
//            List<Student> result = new ArrayList<>();
//            for (Student s : li) {
//                if (function2.apply(s.getName()).equalsIgnoreCase("vipul")) {
//                    result.add(s);
//                }
//            }
//            return result;
//        };
//
//        Student s1 = new Student(2, "vipul");
//        Student s2 = new Student(2,"viplav");
//        Student s3 = new Student(2, "Arnav");
//
//        List<Student> student = Arrays.asList(s1,s2,s3);
//        List<Student> filterStudent =  studentsWithVipAsPrefix.apply(student);
//        System.out.println(filterStudent);
//    }
//
//
//    private static class Student {
//
//        private int id;
//        private String name;
//
//        public Student(int id, String name) {
//        }
//
//        public int getId() {
//            return id;
//        }
//
//        public void setId(int id) {
//            this.id = id;
//        }
//
//        public String getName() {
//            return name;
//        }
//
//        public void setName(String name) {
//            this.name = name;
//        }
//
//



        ///Function changing
        Function<String, String> function1 = x -> x.toUpperCase();
        Function<String, String> function2 = s -> s.substring(0, 3);
        Function<String, String> stringStringFunction = function1.andThen(function2);
        System.out.println(stringStringFunction.apply("Vipul"));
        //or best way
        System.out.println(function1.andThen(function2).apply("vipul "));



    }

}
