package Java8Features;

//we convert collections into Stream for declarative and function programming


import java.util.Arrays;

public class StreamssPractice {

    public static void main(String[] args) {
        //imperative approch (old fashion)\

        int [] array = {1,2,3,4,5};
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 2 == 0){
                sum += array[i];

            }

        }
        int[] array2 = {1,2,3,4,5};
        int sum2= Arrays.stream(array2).filter(n -> n % 2 == 0).sum();

    }
}
// Advantagesss of Stream

// 1) Readability
//2.) Flexibility  (filtering, mapping, and reducing)
//3.) Parallelism
//4.) Encapsulation
