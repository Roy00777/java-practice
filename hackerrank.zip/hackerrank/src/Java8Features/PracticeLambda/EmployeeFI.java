package Java8Features.PracticeLambda;

public interface EmployeeFI {
    // every method expect which have modiefier  are public method
    String getname();


}



