package Java8Features.PracticeLambda;

//public class EmployeeImp implements EmployeeFI {
//    @Override
//    public String getname() {
//        return "Software Engineer";
//    }
//}

// because Lambda we dont need to write the implemation
