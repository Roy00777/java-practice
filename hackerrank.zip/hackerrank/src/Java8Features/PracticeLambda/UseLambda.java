package Java8Features.PracticeLambda;

public class UseLambda {
    public static void main(String[] args) {
//        EmployeeImp employeeImp = new EmployeeImp();
//        System.out.println(employeeImp.getname());


        EmployeeFI employee = ()-> "Software Engineer"; // we use lambda expression because we have only one abstrat method
        // we can use lambda expression only have one abstract method in interface
        System.out.println(employee.getname()); // we can call method directly here itself
    }
}


//function Interface act as datatype for lambda expression
// which means we dont need to write the implemetion class for that interface
// we can directly use it // that means we not need EmployeeImp class for EmployeeFI
// we will use EmployeFI employee = -> our lambda expression