package Java8Features;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConsumerrrsAndSupplerrrs {
    public static void main(String[] args) {

        //creating comsumer
        //consumer having return type void
        //it will accept only\
        Consumer<String> consumer = s -> System.out.println(s);
        consumer.accept("hello world");

        Consumer<List<Integer>> listConsumer = li ->{
             for (Integer i : li){
                 System.out.println(i + 100);
             }
        };
            listConsumer.accept(Arrays.asList(1,2,3,4,5,6));
        Supplier<Integer> supplier = () -> 1;
        System.out.println(supplier.get());


    }
}
