package Java8Features;

// Predicate are the boolean value function
// its a functional interface and have one abstract method which is Test
// Predicate its a genrice type means we can pass datatype or object

import java.util.Objects;
import java.util.function.Predicate;

public class PredicatessPrac {
    public static void main(String[] args) {
        // defining Predicates
        Predicate<Integer> predicate = x -> x > 100000; // here we have created predated where write a condition which is
        System.out.println(predicate.test(100));     // is salary of x is more than 100 we are checking it in this single
        // in the above sout we pass our predicate object which we name predicate we call the method test and we pass the value which is integer type
        // and it will check the condition is true or false

// here we are writting another predicate to see the number is even or odd
        Predicate<Integer> p = x -> x % 2 == 0;
        System.out.println(p.test(54)); // it will give us true

    Predicate<String> startWithV = x -> x.toLowerCase().charAt(0) == 'v';
        System.out.println(startWithV.test("helllo "));


        //Default and static method inside the predicates
        Predicate<String> endWithL = x -> x.toLowerCase().charAt(x.length()-1) == 'l'; //string which should end with letter l
//And :- is type of predicate which will use to intersect two or more predicate for example see below

      Predicate<String> and =  startWithV.and(endWithL);
        System.out.println(and.test("vjljdlfjl"));
//And : In And all the condition should be True then it will show it true otherwise one of the condition is false it will return false


 //OR :- Then there is OR where the one of the condition should be True it will return true if all the condition are false it will return false

        //  we will see same example
        Predicate<String> or = startWithV.or(endWithL);
        System.out.println(or.test("hdhdljl")); // as the condition we need V in the start we put 'h' and in the end we put 'l'
//OR :- for the above example we will get true because one of the condition gets true


 // isEqual :- is static method which means it cannot be overriden
      //	isEqual(Object targetRef)
        //Returns a predicate that tests if two arguments are equal according to Objects.equals(Object, Object).

        // For Example of isEqual we will create  a private class where we will get full clearity
// Here will create object of Student Class

      Student s1 =  new Student("vipul", 1);
      Student s2 =  new Student("Ram", 2);
      Predicate<Student> student = x -> x.getId() > 1;
        System.out.println(student.test(s2));


// we use isEqual to check that the given value is equal or not
   // because isEqual method is static we need to call it using predicate
   Predicate<Object> isEqualPredicate = Predicate.isEqual("vipul");
        System.out.println(isEqualPredicate.test("jdslj")); // it will check the given string( vipul ) and passing string(dsjj) isEqual



    }
    // Creating class for is equal
    private static class Student{
        String name;
        int id;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public Student(String vipul, int i) {
        }
    }
}


