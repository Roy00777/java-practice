package PracticeWithSelf;

//class 1
class Pen{
    String color;
    String type;//ballpoint  gel

    public void write(){
        System.out.println("write some thing");
    }
    // for printing the properties of the pen class
    // we will create new method for printing
    public void printColor(){
        System.out.println(this.color);
    }
}

//creating a  new class 3 practice perpouse
class Student{
    String name;
    int age;
// using of polymorphims
// function overloadigg
 // creating the method
 public void printInfo(String name) {
     System.out.println(name);
 }
 public void printInfo(int age) {
     System.out.println(age);

 }
    public void printInfo(String name, int age){
        System.out.println(this.name);
        System.out.println(this.age);


    }
    // creating Non Parameterize construtor
//    Student(){
//        System.out.println("constructor calling");
//    }
    //parameteries constructor
    // we can initilize the variable here directly
//    Student(String name, int age){
//        this.name=name; // this.name is the object name // and name is the parameter name which we pass
//        this.age=age; // same logic of name appies here

//    }
}

// Now in this class we will create a object of another class
//class 2
public class OOPS{
    public static void main(String[] args) {
        Pen pen1 = new Pen(); // creating an object of Pen class
        pen1.color="blue"; //call the properties of Pen class usin "." dot
        pen1.type="gel"; // we just assign the value to the properties
        pen1.write(); // same using dot we can method of the class

        Pen pen2 = new Pen();
        pen2.color="black";
        pen2.type="ballpoint";

//        pen1.printColor();
//        pen2.printColor();

       // Student s1 = new Student("shantanu",24); //after creating the parameteris consturctor we directly pass the value here
       //s1.name="Shantanu";
//        s1.age=28; // we can call this directly in parameteries constructor
        Student s1 = new Student();
       s1.printInfo(s1.name,s1.age); // call the method which we created in student class



    }
}
