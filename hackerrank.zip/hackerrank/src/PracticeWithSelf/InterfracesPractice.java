package PracticeWithSelf;
//its use to extract pure abstrction
interface Animalo {
    // we cannot create the counstorctor
        // we cannot create non abstract function and nor its implemtaition

 void walk();
}
class Horses implements  Animalo{
        @Override
        public void walk() {
                System.out.println("Animal can walk");

        }
}


public class InterfracesPractice{

        }
