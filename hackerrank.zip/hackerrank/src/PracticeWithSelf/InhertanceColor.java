package PracticeWithSelf;
//
public class InhertanceColor {
    String color;
}
// Single level Inhirtaance
// a class direved from other class
// a class which direved its called child and
//from which class its direved its called Parent
class Shape{
    public void area(){
        System.out.println("display area");
    }

}
class Triangle extends Shape {
    public void area(int l, int h){
        System.out.println(1/2*l*h);
    }

}
// Multi level inheritance
// Multi level inheritance is heritance which occured when we drived a class from a child class which is direved from parent class
class EquilateralTriangle  extends Triangle{
    public void area(int l, int h){
        System.out.println(1/2*l*h);
    }


}
// Hierarchial inheritance
// in hierchial inheritance we have single base class in our case it shape
// And have many child class in our case Circle and Triangle and we can create nth of class
 class Circle extends Shape{
    public void area(int r){
        System.out.println((3.14)*r*r);
    }
}
//Hybrid inheritance
//its a class where we got to see the mixture of all the inheritance

class OOPs {
    public static void main(String[] args) {

    }

}


