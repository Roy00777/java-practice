package PracticeWithSelf;

public class
Abstraction {
}

// abstract means a vision or we can called it a basics of the code
 class Animal {


    // we dont need to write the implemntation of the abstract method
    public void walk(){
        int a  = 100;
    } // abstact method
    public void eats(){ // normal method we need to write implemention of it
        System.out.println("Animal cann eat");
    }
    // we can create the counstroctor in abstaction
    Animal(){
        System.out.println(" we are creating a counstracto of an  Abstact class");
    }
}
class Horse extends Animal{

    public void walk() {

        System.out.println("Walks on 4 legs");
    }
}
class Hen extends Animal{

    public void walk() {
        System.out.println("walks on 2 legs");
    }
}
class opp{
    public static void main(String[] args) {
        Horse horse = new Horse();
        horse.walk();
        horse.eats(); // we did not define eat in horse its inherit form abstact class Animal
    }
}
