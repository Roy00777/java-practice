package PracticeWithSelf;

public class Encapsulation {
}
// first we will look into Access modifier

class Account{
    //public will accessable by every packages and class which are in or out of the packages
    public String name;
    // it will be accesable to its class and packages not outside of its packages
    protected String email;
    // it will be accessable in it self calss  only
    private String password;
// if you want to access the password we can use getter and setter
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
class Bank{
    public static void main(String[] args) {
       Account account = new Account();
       account.name="abcd";
       account.email="abcd@gamil.com";
       account.setPassword("abcd");
        System.out.println(account.getPassword());

    }
}