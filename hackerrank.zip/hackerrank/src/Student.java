import java.util.Objects;

class Student {
String name;
int rollno;
 public Student(String name, int rollno){
     this.name = name;
     this.rollno = rollno;
 }


// behind the seen the hashset use hasequal method
     //we are writing this because we need diffrenet roll no to every one
     // and should not get same rollno to any stundent

     @Override
     public String toString() {
         return "Student{" +
                 "name='" + name + '\'' +
                 ", rollno=" + rollno +
                 '}';
     }
     //after using eqal and hash
    // we can diffrentsiate student on there rollno
    // so there is no duplication in roll no
 // these code is genrate through Alter+inster

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return rollno == student.rollno;
    }

    @Override
    public int hashCode() {
        return Objects.hash(rollno);
    }

////    @Override
//    public int compareTo(Objects that) {
//        return this.rollno - that.rollno;
//    }


}
