package Multithreding;

class UserThread implements Runnable{

    @Override
    public void run() {
        //********* Run
        // it will store the task of the thread

        System.out.println("This is use define Thread.");

    }
}


public class ThreadOpreation {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("program started.");

        int x = 56+34;
        System.out.println("Sum is this"+" "+x);


        //Getting the Thread Name
        //we will try to print the name of Thread
        //main is also a thread
        //currentThread give us the thread on which one we areo n
       Thread t1 = Thread.currentThread();
       String threadName =t1.getName(); // getName() will give as the thread name
        System.out.println("Current thread and the name of  thread is "+threadName);

//****Setting up the Thread name

        t1.setName("Second name");
        System.out.println("setting a new name is :" + t1);

        //Sleep method is static
        // we can call it directly
        // will takes a delation of 2 sec
        // this Sleep throws a Exception thats why we us Throws Exception on the top of the class

        Thread.sleep(2000);

        // getting the Id of the Thread

        System.out.println(t1.getId());


        // Going to Start User Defined Thread




        System.out.println("program ended.");


    }
}
