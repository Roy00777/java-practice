package Multithreding;
//Creating Thread Using Runnable Interface
//Best way to use  Multithreading is Runnable because we can use Thread class
//means we don't get error of multiple inheritance

public class MyThread implements Runnable {

    // we will Write the Code which we want execute by thread
    @Override
    public void run() {
        for (int i = 1 ; i <=5; i++){
            System.out.println("using Runnable in MyThread"+" "+i);
            try {
                //it will wait till one sec for everytime in the loop
                // we need pass time in miniseconds in sleep
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }

    public static void main(String[] args) {
        //here we create a object of our class for refernce which will pass in thread
        // t will pass in thread
        MyThread t1 = new MyThread();


        // creating a object of thread which will execute the method of run
        Thread thread = new Thread(t1);
        thread.start();


        // trying to create the object of the MyAnotherClass
        // so we can run the Thread which we have created in it

        MyAnotherThread thread2 = new MyAnotherThread();

        thread2.start();




    }
}
