package Multithreding.ProducerAndConsumer;

//same as the producer we have to create the code



public class ConsumerThread extends Thread {
    Company c;

    ConsumerThread(Company c){
        this.c=c;

    }

    @Override
    public void run() {
        while (true){
            this.c.consume_item();
            try {
                Thread.sleep(2000);
            }catch (Exception e){
                System.out.println("if Exception caught at counsumer side");
            }
        }


    }
}
