package Multithreding.ProducerAndConsumer;



public class ProducerThread extends Thread {
    // ab hame pata hai jike liye thread banana hai usekeliye
    // us class ka object chaiye
    // apne case wo Company ka banenga
    Company c;

    //ab ProducerThread ka Constructor banke
    //usme Comanpy ka object pass karenge
    // jab producerThread ka object call honga wo
    // c me jayga jo counstror bany uske c  or waha
    // se company ke object me
ProducerThread(Company c){
    this.c=c;
}

@Override
    public void run() {
    //produce item kar rahe hai apn
    // apn abhi integer print karenge means apne item
    // infinet karan apneko to
 int i= 1;

    while (true){
        this.c.produce_item(i);
        i++;
        try {
            Thread.sleep(2000);
        }catch (Exception e){
            System.out.println("if any Exception caught");
        }


    }

    }
}
