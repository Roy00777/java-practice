package Multithreding.ProducerAndConsumer;

public class Company {

    //if compnay ke pass ek producer agya "n"
    int n;
    //comunication between thread
    boolean f = false;
    //if f is false // then producer produce the item
    //then consumer will wait





    //to usko pass karlo produce item me
    //we are using Synchornized for
    //jab ek thread chale dusrene interpert in karne hona
   synchronized public void produce_item(int n){
       if(f){
           try {
               wait();
           }catch (Exception e){
               System.out.println(" exception caught at company class producer_item method");
           }
       }
        this.n =n;
        System.out.println("produce : "+this.n);
        f=true;
        notify();

    }

    //ya per isliye jab consumer consume kar raha honga
    //tab produser ka chance
    //if f is true then its a chance for consumer
    //thats why we write if condition for f
    synchronized public int consume_item(){
        if (!f){
            try {
                wait();
            }catch (Exception e){
                System.out.println("exception caught in Compay class at conumser method");
            }

        }
        System.out.println("consumed : " +this.n);
        f =false;
        notify();
        //notify function bata denga kam hogya

        return this.n;

    }

}
