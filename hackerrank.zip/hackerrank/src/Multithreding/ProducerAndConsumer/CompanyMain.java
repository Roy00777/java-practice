package Multithreding.ProducerAndConsumer;

//yaha main un dono class ke means ProducerThread
//or CounsumerThread ke Thread create kar ke start karenge

public class CompanyMain {
    public static void main(String[] args) {
        Company company= new Company();
        ProducerThread p =new ProducerThread(company);
        ConsumerThread c = new ConsumerThread(company);
p.start();
c.start();
    }
}
