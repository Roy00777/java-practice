package Multithreding;
//Creating thread using Extends Thread Class

public class MyAnotherThread extends Thread {
    @Override
    public void run() {
        //loop for thered class

        for (int i =10; i>0; i--){
            System.out.println("Extended Thread in MyAnotherThread Class:"+" "+i);
        //now we need some delaytion in output
        // so we will use sleep
            //we need sleep in try catch because its checked Exception
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }


        }

    }

    public static void main(String[] args) {
        //Here we dont need to create our class object because
        // Thread class extend thee property of Runnable
        // so we can directly create Thread class object
        // and run it

      Thread thread2 = new Thread();
      // we will write
        thread2.start(); // it will automaticly the execution
        // its start without any reference which thread should start
        // that why we ignore the Thread class
        // use Runnable for best purpose
    }

}
