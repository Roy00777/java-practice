import java.util.Scanner;

public class Pencil_Count
{
    public static void main(String[] args) {
        int a =0;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any std");
    int std= scan.nextInt();
    for(int i=1; i<=std; i++)
        if(i<=1){
            System.out.println("1 pencil");

        }

    }

}
