package college;

import java.util.Scanner;

public class Byte {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("enter any no");
        int num = scan.nextInt();
        for (int i = 1; i <= num; i++) {
            if(i<num) {
                System.out.println(i + ",");
            }
            else {
                System.out.println(i+".");
            }
            }
    }
}
