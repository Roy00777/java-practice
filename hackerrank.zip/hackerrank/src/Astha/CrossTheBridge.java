//package Astha;
//
//import javax.imageio.stream.ImageInputStream;
//import java.util.Scanner;
//
//public class CrossTheBridge {
////    int size ;
////    int ab=0;
//    int sum=0;
//   int maxWeight =350;
////    int carryCapacity []= new int[size];
//   int minimumTrip = 0;
//    public int leastNumber(int[]boxWeight, int carryCapacity, int maxWeight) {
//        for (int i = 0; i < carryCapacity; i++) {
//            carryCapacity = carryCapacity + i;
//            if (carryCapacity == 200)
//                System.out.println("work will not carry combined boxes");
//
//            else if (carryCapacity < 200) {
//                System.out.println("It will take more than one trip");
////
//           }// else if (maxWeight<=carryCapacity) {
////                sum=sum+carryCapacity/100;
//                return minimumTrip;
//
//
//           // }
//
//
//        }
//
//    }
//
//    public static void main(String[] args) {
//
//
//        Scanner scan=new Scanner(System.in);
//        int size=0;
//        int[]boxweight=new int[size];
//
//        for (int i = 0; i<=size ; i++) {
//            boxweight[i]=scan.nextInt();
//
//        }
//        for (int i = 0; i <boxweight[i] ; i++) {
//            System.out.println(size);
//
//        }
//
//    }
//}
