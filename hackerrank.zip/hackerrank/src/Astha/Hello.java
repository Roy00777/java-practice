package Astha;
//
//import javax.swing.*;
//import java.util.Scanner;
//
//public class Hello {
//    public static void main(String[] args) {
//        System.out.println("Hello Ry");
//        int sum = 0;
//        int array[] = {50, 50, 100, 50, 50};
//
//        int a[] = {100, 100, 50, 100};
//        int b[]={50,50};
//
//        for (int i = 0; i < array.length; i++) {
//            sum = sum + array[i];
//
//
//        }
//        int x = sum / 100;
//        System.out.println("the trip "+x);
//
//        int a1 = 0;
//        for (int i = 0; i < a.length; i++) {
//            a1 = a1 + a[i];
//            if(a[i]=100){
//                System.out.println("it will take one trip");
//            } else if (a[i]==50) {
//                int xy =
//
//            }
//
//        }
//        int aa= a1/100;
//        System.out.println("trip taken" + aa);
//int bb=0;
//        for (int i = 0; i < b.length; i++) {
//            bb=bb+b[i];
//
//        }
//        int xx=bb/100;
//        System.out.println("trip taken"+ xx);
//
//    }
//    }
//
//
//
//




class Birthdaygift {
    public static void main(String[] args) {
        int digit = 3; // Geetika's lucky digit
        int age = 2; // Geetika's age
        int lastTicket = 72; // Serial number of last sold ticket

        int nextTicket = getNextTicket(digit, age, lastTicket);
        System.out.println("Next ticket Arnav should buy: " + nextTicket);
    }

    public static int getNextTicket(int digit, int age, int lastTicket) {
        int ticket = lastTicket + 1;

        while (true) {
            int count = 0; // Reset count for each ticket
            String ticketStr = String.valueOf(ticket);
            for (int i = 0; i < ticketStr.length(); i++) {
                if (ticketStr.charAt(i) - '0' == digit) {
                    count++;
                }
            }
            if (count == age) {
                return ticket;
            } else {
                ticket++;
            }
        }
    }
}


