package ExceptionHandling;
//finallly block will always run
// if execption occurs or not in the code

public class FinallyBlockInException  {
    public static void main(String[] args) throws Exception {
        int[] arr = new int[6];
        System.out.println("Hello World ");
        try{
            System.out.println(arr[9]);
        }catch (Exception e){
            System.out.println("Exception handle here");
        }finally {
            System.out.println("I will run always");
        }
// if there is exception which can occurs
        // so we can take prevation using throws
        // for example we are creating a method
        // we just use throws in front of


    getNumberFromArray(arr);


        }
        // Now in these method we will get error
    // because of the ssize of an array\
    // so we will handle it using throws keyword in fornt of method
    static int getNumberFromArray(int[] arr) throws Exception {
        return arr[8];
    }
    // throws function used to means bataneko dusre method ko ki ya execption
    // aasakti hai
    // apne case me jaise hi Throws lagaya getNumberFromArray ke same
    //  or Exception likha
    // main method ka getNumberFromArray jise apn call kar rahe the
    // wo red hogya
    // wo refrence dera raha tha ki mere method pe throws likha huva hai l
    // to ap bhi throw likh ke try catch likh le getNumberFromArray

}

