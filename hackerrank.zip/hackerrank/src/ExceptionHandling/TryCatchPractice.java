package ExceptionHandling;
//the try catch block in java is ude to handle exceptions ans prevents
// the abnormal termination of the program
public class TryCatchPractice {
    public static void main(String[] args) {
        int a[] = new int[5];
        // the array size is 5
        //but what will happen if i will try to print the
        // 8th postion of the array which is not present in the array
        // thats write it show us an exception IndexOutOfBound


       //******************* System.out.println(a[8]); ************// this not showing our error means this is runtime errors




        // which will be show case at the time of the execution the program

        //afterr the error caught we know the program will get terminate
        // the rest of the code which we have written will not going to exeute
        // because of that error
        System.out.println("hello world");
        // thats why we use try catch block error
        // if exception occers it will not stop eniter the execution
        // but return as the error and complete the execution
        // now we will try and catch block


        try {
            System.out.println(a[8]);



        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("try to array to out of bound element");
            System.out.println(e.fillInStackTrace());
            System.out.println(e.getCause());
//        }catch(ArithmeticException e){ // we can have multiple catch block
//            System.out.println(e.fillInStackTrace());
//            System.out.println(e.getCause());
            // we can have more information about the
            // excpection using e dot we get many function to use
            // above example see we are get the cause of exception
            // and the fillINStackTrance of it
            // there are many more of the funtion


            // if you have similer output to print the execptio
            // but on different condition like
            //you printing "error cause" in sout for
            // Arithmatic excepection, Null pointer or etc
            // and you just wanted to print the output
            // the you can use like below part
            // we can use pipe sepretion login in catch
        }catch(ArithmeticException | NullPointerException  e){
            System.out.println("error caugt");
        }finally {
            System.out.println("its a finally block");
            System.out.println("its a finally block");
        }
        // but if you are writing a logic to handle the exception then
        // should write the logic in different catch block we can create n number block
        System.out.println("Good bye");

    }


}
