package ExceptionHandling;

import java.util.Scanner;

// I am creating a mine own Exception thats why I am creating new class Exception
public class CustomExceptionThrow {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Age");
        try{
            int age = sc.nextInt();
            if (age > 100){
                throw new ExceptionCustom();
            }
        }catch (Exception e){
            System.out.println(e);
        }

    }
}

class ExceptionCustom extends java.lang.Exception {

}