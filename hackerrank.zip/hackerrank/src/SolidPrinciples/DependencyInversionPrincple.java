package SolidPrinciples;
//class should depend on interfaces rather than concerte classes


import javax.crypto.Mac;
import java.awt.event.MouseAdapter;

// if we have macbook
// and having two croncret class which are keyboard and mouse
// in keyboard we have wired and bluetooth same in mouse wired and bluetooth
public class DependencyInversionPrincple {
}

//what will happed if we use this concret class object

class keyboard{
    String wiredKeyBoard;
    String BluetoothkeyBoard;
}
class Mouse{
    String wiredmouse;
    String bluetoothmouse;
}
class MacBook {
    //create the object of the concret class
    private keyboard keyboard;
    private Mouse mouse;

}
