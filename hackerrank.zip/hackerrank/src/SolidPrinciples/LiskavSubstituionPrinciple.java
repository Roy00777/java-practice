package SolidPrinciples;

//Explation
// if class is B is subtype(child class) of class A, then we should be able
//to replace object of A with B without Breaking the behaviour of the program
 // subclass should extend the capability of the parent class

public class LiskavSubstituionPrinciple {
}
 interface Bike{
    void turnOnEngine();
    void accelerate();
 }
 class MotorCycle implements Bike{
    boolean isEnginon;
    int speed ;

     @Override
     public void turnOnEngine() {
         isEnginon=true;
     }

     @Override
     public void accelerate() {
        speed =speed+20;
     }
 }
 // if i am extending the bike into bycycle
// then it will narrow the parent class
class Bycycle implements Bike{
    //somc code
     public void turnOnEngine(){
         throw new AssertionError("there is no engine");
     }

     @Override
     public void accelerate() {

     }
 }

