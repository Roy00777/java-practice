package SolidPrinciples;
//interfaces should be such, that client should not implement
//unnecessary function they do not need

// explenation of it
// suppose we create a interface which having  too many method
// but a Sinario is happen where we need of the method of interface
// so we cant implement all method of that interface
// The rules make some  small interfaces which is easly use by anyone and any condition


// we will took an example of resturent

public class InterfaceSegmentedPrincple {
}

//we create a interface of resturent employ which having some method
interface resturnetEmploy{
    void washdies();
    void servefood();
    void cookfood();

}
// Now in this case we don't  need to apply all of the method of the interface
//because waiter olny serve the food not cook the food or wash the dishes this
// work of the helper
// So now we will create some small interface
class waiter implements resturnetEmploy{

    @Override
    public void washdies() {

    }

    @Override
    public void servefood() {

    }

    @Override
    public void cookfood() {

    }
}

// we are creating a same interfaces means having less number of method
interface waiters{
    void servefood();

}
interface helperboy{
    void washdishes();
    void greetTheGusest();

}
//Now we can impelemet the waiter interface to waiter class
// that means we dont need to impeletment other interfaces

class waiterss extends waiter {

}
