package SolidPrinciples;

//open for Extension but closed for Modification

public class OpenAndClosePrinciple {
}

// so if you project is live then there is  a client request come that the Invoice
// which you are saving in dao its should be in file

class InvoiceeeDao{
    /*some code
    .......
    */
    /*
    if we change some some thing the InvoiceeeDao class which is live
    in production
    it will affect it
    so what can we do
    then the Open close pricnple came
    a class should be extend not should be modify

     */
}

/* Explanation
so is there are class which are going to change we can create the another class
that class which will not affect the orignal code
 */
//Example
// I am creating a interface which will be implement on another class the orignal interface will remain untouch
 interface inovceedao{
     //come code
}


class invoceeeedao implements inovceedao{
     // we can write the extension part of it

}