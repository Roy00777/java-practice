package SolidPrinciples;

//A Class should have only 1 reason to change
//easy to maintain
// Explanation
// we will create different class for all the method which will or impact on the main code
//Example


//suppose this a marker Entity
//SingleResponsibilityPrincple  is Marker
public class SingleResponsibilityPrincple {
    String name;
    String id;
    String price;

    public SingleResponsibilityPrincple(String name, String id, String price){
        this.name = name;
        this.id=id;
        this.price =price;
    }

}


//Now we are creating another class for the Marker entity which
// is having entier  logic  of the program

class Invoice{
    // creating the object of an Marker class which will having the properties of it
    private SingleResponsibilityPrincple singleResponsibilityPrincple;
    private int quantity;
    //some logic we will wirte here
    public Invoice (SingleResponsibilityPrincple singleResponsibilityPrincple, int quantity){
        this.singleResponsibilityPrincple=singleResponsibilityPrincple;
        this.quantity=quantity;
    }

//    public int calculation(){
//        int price= ((singleResponsibilityPrincple.price)*(this.quantity));
//        return price;
//    }
    public void printInovice(){
        //some code which will be written or chage because of any resquest of cilent
    }

public void saveToDb(){
        //some code which will be change
}
/// As per the S of the SOILD Princple
    // there should only one reason to change
    // in the above case we are having multiple
    // like method printInovice and saveToDb will change in future or xyz reason
    // the all code will affect when we change something in one method
    // So to over come this problem we create new class of the PrintInvoice and saveDao
    // which means there will no changes affect on both of the class and its logic
}
 class InvoicePrint{
    //some code
     // we will create the object of the class if we need there properties
     private Invoice invoice;
     public InvoicePrint(Invoice invoic){
this.invoice=invoice;
 }
}
// same goes for the doa
class InvoiceDao{
}
//some code