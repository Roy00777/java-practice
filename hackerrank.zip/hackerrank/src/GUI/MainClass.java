package GUI;

public class MainClass {
    public static void main(String[] args) {
        Application  gui = new Application();
    }
}
