package GUI;

import javax.swing.*;

public class Application {
    JFrame jFrame;
    public  Application() {
         jFrame = new JFrame();
           jFrame.setBounds(100,200,400,400);
           jFrame.setVisible(true);
           jFrame.setTitle("Binary Brains");


    }

}
