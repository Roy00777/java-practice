import java.util.Scanner;
//Fibonaci series
public class LOOPs
{
    public static void main(String[] args) {
       int b=0;
        Scanner scan = new Scanner(System.in);


        System.out.println("Enter any no");
        int num = scan.nextInt();
        for(int i=1; i<=num; i++) {
//            System.out.println(num);
            b=b+i;

        }
        System.out.println("addition is :"+b);
    }
}
